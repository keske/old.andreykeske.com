<?

$dirop = opendir("./source/");
$max = 0;

while (gettype($file=readdir($dirop)) != 'boolean') {
if ($file != "." && $file != ".." && $file != "source" && $file != ".DS_Store") {
	$max++;
	$mas[$max] = $file;
    }
}

closedir($dirop);

if (file_exists("1.jpg")) {  unlink("1.jpg");  }
if (file_exists("2.jpg")) {  unlink("2.jpg");  }

$a = mt_rand(1,$max);
$ok = 0;

while ($ok == 0) {
     $ok = 0;
     $b = mt_rand(1,$max);
     if ($a != $b) { $ok = 2; }
}

copy("source/".$mas[$a],"1.jpg");
copy("source/".$mas[$b],"2.jpg");

?>
