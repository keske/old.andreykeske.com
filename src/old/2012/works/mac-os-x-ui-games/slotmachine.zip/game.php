<?

function generateFileName($length){
      $chars = 'abdefhiknrstyzABDEFGHKNQRSTYZ23456789';
      $numChars = strlen($chars);
      $string = '';
      for ($i = 0; $i < $length; $i++) {
        $string .= substr($chars, rand(1, $numChars) - 1, 1);
      }
      return $string;
}	

$dirop = opendir("./source/");
while (gettype($file=readdir($dirop)) != 'boolean') {
    if ($file != "." && $file != ".." && $file != "source" && $file != "index.php" && $file != "first" && $file != ".DS_Store") {
        $stroka=0;

        for ($i=1;$i<=50;$i++) {
            $file2=generateFileName(15).".jpg";
            copy("source/".$file,"first/".$file2);
        }
    }
}

closedir($dirop);

$dirop = opendir("./source/");
while (gettype($file=readdir($dirop)) != 'boolean') {
    if ($file != "." && $file != ".." && $file != "source" && $file != "index.php" && $file != "second" && $file != ".DS_Store") {
        $stroka=0;

        for ($i=1;$i<=50;$i++) {
            $file2=generateFileName(15).".jpg";
            copy("source/".$file,"second/".$file2);
        }
    }
}

closedir($dirop);

$dirop = opendir("./source/");
while (gettype($file=readdir($dirop)) != 'boolean') {
    if ($file != "." && $file != ".." && $file != "source" && $file != "index.php" && $file != "third" && $file != ".DS_Store") {
        $stroka=0;

        for ($i=1;$i<=50;$i++) {
            $file2=generateFileName(15).".jpg";
            copy("source/".$file,"third/".$file2);
        }
    }
}

closedir($dirop);



?>
